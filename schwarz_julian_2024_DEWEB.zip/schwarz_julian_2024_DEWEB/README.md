# DEWEB
Hockey Game

Das Projekt in einer IDE öffnen, index.html ausführen und das Projekt sollte starten.
